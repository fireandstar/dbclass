package com.example.db_class.bean;

public class takein {
    private long id;
    private String vName;
    private String time;
}
