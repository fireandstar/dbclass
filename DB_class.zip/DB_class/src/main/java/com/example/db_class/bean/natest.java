package com.example.db_class.bean;

public class natest {
    private long id;
    private long testID;
    private String time;
    private String result;
}
