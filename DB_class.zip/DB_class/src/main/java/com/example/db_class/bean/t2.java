package com.example.db_class.bean;

import lombok.Data;

@Data
public class t2 {
    private long id;
    private String name;
    private String city;
    private String situation;
    private String phoneNum;
    private int days;
}
