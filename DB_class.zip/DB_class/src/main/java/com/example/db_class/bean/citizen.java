package com.example.db_class.bean;

import lombok.Data;

@Data
public class citizen {
    private long ID;
    private String name;
    private String phoneNum;
}
