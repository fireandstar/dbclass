package com.example.db_class.bean;

public class city {
    private String city;
    private String situation;
}
