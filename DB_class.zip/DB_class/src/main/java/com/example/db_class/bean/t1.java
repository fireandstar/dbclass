package com.example.db_class.bean;

import lombok.Data;

@Data
public class t1 {
    private long testID;
    private String name;
    private String time;
    private String result;
}
