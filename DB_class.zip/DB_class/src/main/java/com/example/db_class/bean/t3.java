package com.example.db_class.bean;

import lombok.Data;

@Data
public class t3 {
    private long id;
    private String name;
    private String vName;
    private String time;
    private String company;
}
