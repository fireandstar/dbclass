package com.example.db_class.bean;

import lombok.Data;

@Data
public class t4 {
    private long id;
    private String name;
    private String time;
    private String result;
}
