package com.example.db_class.bean;

public class stay {
    private long id;
    private long duringTimeDays;
    private String city;
}
