package com.example.db_class.controller;
import com.example.db_class.bean.*;
import com.example.db_class.mapper.SqlMapper;
import com.google.gson.Gson;

import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@CrossOrigin(origins={"*","null"})
@RestController
public class CitizenController {
    @Autowired
            private JdbcTemplate jdbcTemplate;
    @Autowired
    SqlMapper sqlMapper;
    private final Gson gson1=new Gson();
    @PostMapping("/res1")
    public String res1(@RequestBody String search1){
        JSONObject JO=JSONObject.fromObject(search1);
        String s1=JO.getString("name");
        String s11=JO.getString("id");
        String sql;
        List<citizen> citizens=null;
        if((s11==null|| s11.equals(""))&&(!Objects.equals(s1, "") &&s1!=null))
        {
            sql="select * from citizen where name like CONCAT('%',?,'%')";
           citizens= jdbcTemplate.query(sql,new Object[]{s1}, new BeanPropertyRowMapper(citizen.class));
        }

        else if((Objects.equals(s1, "") ||s1==null)&&(s11!=null&& !s11.equals("")))
        {
            sql="select * from citizen where id= ?";
            int i11=Integer.parseInt(s11);
            citizens= jdbcTemplate.query(sql,new Object[]{i11}, new BeanPropertyRowMapper(citizen.class));
        }

        else if(!Objects.equals(s1, "") &&s1!=null&&s11!=null&& !s11.equals(""))
        {
            sql="select * from citizen where name like CONCAT('%',?,'%') and id=?";
            int i11=Integer.parseInt(s11);
            citizens= jdbcTemplate.query(sql,new Object[]{s1,i11}, new BeanPropertyRowMapper(citizen.class));
        }


        return gson1.toJson(citizens);
    }
    private final Gson gson2=new Gson();
    @PostMapping("/res2")
    public String res2(@RequestBody String search1){
        JSONObject JO=JSONObject.fromObject(search1);
        String s2=JO.getString("name");
        String s22=JO.getString("id");
        String sql;
        List<t2> infs=null;
        if((s22==null|| s22.equals(""))&&(!Objects.equals(s2, "") &&s2!=null))
        {
            sql="select id,name,city,situation,phone_num,stay.days from citizen natural join city natural join stay where name like CONCAT('%',?,'%')";
            infs= jdbcTemplate.query(sql,new Object[]{s2}, new BeanPropertyRowMapper(t2.class));
        }
        else if((s2==null|| s2.equals(""))&&(!Objects.equals(s22, "") &&s22!=null))
        {
            int i22=Integer.parseInt(s22);
            sql="select id,name,city,situation,phone_num,stay.days from citizen natural join city natural join stay where id=?";
            infs= jdbcTemplate.query(sql,new Object[]{i22}, new BeanPropertyRowMapper(t2.class));
        }
        else if((!Objects.equals(s2, "") &&s2!=null)&&s22!=null&& !s22.equals(""))
        {
            int i22=Integer.parseInt(s22);
            sql="select id,name,city,situation,phone_num,stay.days from citizen natural join city natural join stay where name like CONCAT('%',?,'%') and id=?";
            infs= jdbcTemplate.query(sql,new Object[]{s2,i22}, new BeanPropertyRowMapper(t2.class));
        }
        return gson2.toJson(infs);
    }
    private final Gson gson3=new Gson();
    @PostMapping("/res3")
    public String res3(@RequestBody String search3){
        JSONObject JO=JSONObject.fromObject(search3);
        String s3=JO.getString("name");
        String s33=JO.getString("id");
        String sql;
        List<t3> infs=null;
        if((s33==null|| s33.equals(""))&&(!Objects.equals(s3, "") &&s3!=null))
        {
            sql="select id,name,vname,time,company from citizen natural join takein natural join vaccines where name like CONCAT('%',?,'%')";
            infs= jdbcTemplate.query(sql,new Object[]{s3}, new BeanPropertyRowMapper(t3.class));
        }
        else if((s3==null|| s3.equals(""))&&(!Objects.equals(s33, "") &&s33!=null))
        {
            int i33=Integer.parseInt(s33);
            sql="select id,name,vname,time,company from citizen natural join takein natural join vaccines where id=?";
            infs= jdbcTemplate.query(sql,new Object[]{i33}, new BeanPropertyRowMapper(t3.class));
        }
        else if((!Objects.equals(s3, "") &&s3!=null)&&s33!=null&& !s33.equals(""))
        {
            int i33=Integer.parseInt(s33);
            sql="select id,name,vname,time,company from citizen natural join takein natural join vaccines where id=? and name like CONCAT('%',?,'%')";
            infs= jdbcTemplate.query(sql,new Object[]{i33,s3}, new BeanPropertyRowMapper(t3.class));
        }
        
        return gson3.toJson(infs);
    }
    private final Gson gson4=new Gson();
    @PostMapping("/res4")
    public String res4(@RequestBody String search4){
        JSONObject JO=JSONObject.fromObject(search4);
        String s4=JO.getString("name");
        String s44=JO.getString("id");
        String sql;
        List<t4> infs=null;
        if((s44==null|| s44.equals(""))&&(!Objects.equals(s4, "") &&s4!=null))
        {
            sql="select id,name,time,result from citizen natural join natest where name like CONCAT('%',?,'%')";
            infs= jdbcTemplate.query(sql,new Object[]{s4}, new BeanPropertyRowMapper(t4.class));
        }
        else if((s4==null|| s4.equals(""))&&(!Objects.equals(s44, "") &&s44!=null))
        {
            int i44=Integer.parseInt(s44);
            sql="select id,name,time,result from citizen natural join natest where id=?";
            infs= jdbcTemplate.query(sql,new Object[]{i44}, new BeanPropertyRowMapper(t4.class));
        }
        else if((!Objects.equals(s4, "") &&s4!=null)&&s44!=null&& !s44.equals(""))
        {
            int i44=Integer.parseInt(s44);
            sql="select id,name,time,result from citizen natural join natest where id=? and name like CONCAT('%',?,'%')";
            infs= jdbcTemplate.query(sql,new Object[]{i44,s4}, new BeanPropertyRowMapper(t4.class));
        }

        return gson4.toJson(infs);
    }
    private final Gson gson=new Gson();
    @GetMapping("/getcitizens")
    public String get_citizens(){
        List<citizen> citizens=sqlMapper.selectList(null);
        return gson.toJson(citizens);
    }

}
