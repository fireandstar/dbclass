package com.example.db_class.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.db_class.bean.citizen;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface SqlMapper extends BaseMapper<citizen> {
}
