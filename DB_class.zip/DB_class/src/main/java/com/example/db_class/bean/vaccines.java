package com.example.db_class.bean;

public class vaccines {
    private String vName;
    private String company;
}
