package com.example.db_class;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.example.db_class.mapper")
public class DbClassApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbClassApplication.class, args);
    }

}
